CLEARLY KIND — MEMBER 1 STARTER PROJECT

Files included:
- index.html       Homepage
- about.html       About Us page
- css/style.css    Shared styling
- js/login.js     Homepage login prompt

HOW TO OPEN IN VS CODE
1. Extract the ZIP file.
2. Open Visual Studio Code.
3. Select File > Open Folder.
4. Choose the extracted clearly_kind_member1 folder.
5. Open index.html.
6. If you have the Live Server extension, right-click index.html and choose "Open with Live Server".
   Otherwise, you can open index.html directly in your browser.

IMPORTANT GROUP INTEGRATION
The navigation links to products.html, contact.html and media.html.
Those files must be supplied by the other group members and placed beside index.html.
Agree with your group on the shared folder and filenames before combining everyone's work.

LOGIN DEMONSTRATION
The login prompt is a classroom demonstration only. It is not a real account system and does not authenticate users against a database.

IMAGE NOTE
The sample design uses online Unsplash image URLs. An internet connection is needed for those images to load.
