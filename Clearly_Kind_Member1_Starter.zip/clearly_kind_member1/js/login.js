// CLEARLY KIND — simple demonstration login prompt
// This is a classroom demonstration, not a real secure login system.

const loginButton = document.getElementById("loginButton");

if (loginButton) {
    loginButton.addEventListener("click", function () {
        const username = prompt("Welcome to Clearly Kind! Please enter your username:");

        // Check whether the user cancelled or entered only spaces.
        if (username === null || username.trim() === "") {
            alert("Login cancelled. Please enter a username to continue.");
            return;
        }

        // Classroom rule: username must be "admin" or contain more than 5 characters.
        if (username.trim().toLowerCase() === "admin" || username.trim().length > 5) {
            alert("Login Successful. Welcome to Clearly Kind, " + username.trim() + "!");
        } else {
            alert("Login Failed. Use 'admin' or a username with more than 5 characters.");
        }
    });
}
